const button =
document.getElmentByeId('playbutton');
button.addEventListener('click' () =>{
  //This changes the page to a new URL
  window.location.href =
    "https://google.com-link.html";
});