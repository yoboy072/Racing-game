const button = document.getElementById('playButton');

button.addEventListener('click', () => {
  window.location.href = "https://google.com-link.html";
});